package com.example.marsphotos.model

data class Usuario(val matricula : String)
